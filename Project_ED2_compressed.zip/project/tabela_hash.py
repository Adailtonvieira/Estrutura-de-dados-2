class TabelaHash:
    def __init__(self, tamanho):
        self.tamanho = tamanho
        self.tabela = [[] for _ in range(tamanho)]
    
    def funcao_hash(self, chave):
        return chave % self.tamanho
    
    def inserir(self, chave):
        indice = self.funcao_hash(chave)
        self.tabela[indice].insert(0, chave)
    
    def obter_dados_tabela(self):
        return enumerate(self.tabela)
    
    def imprimir_tabela(self):
        print("\n" + "=" * 50)
        for indice in range(self.tamanho):
            lista = self.tabela[indice]
            print(f"Indice {indice:2d} |", end=" ")
            if not lista:
                print("VAZIO")
            else:
                print(" -> ".join(str(chave) for chave in lista))
        print("=" * 50 + "\n")