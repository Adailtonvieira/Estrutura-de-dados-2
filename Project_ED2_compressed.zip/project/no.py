class No:
    def __init__(self, chave):
        self.chave = chave
        self.proximo = None