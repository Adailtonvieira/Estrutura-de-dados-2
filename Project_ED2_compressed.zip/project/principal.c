#include <stdio.h>
#include "tabela_hash.h"

int main() {
    int chaves[] = {5, 28, 15, 20, 33, 12, 7, 10};
    int num_chaves = 8;
    
    printf("\nTabela Hash com m = 9:\n");
    TabelaHash* th9 = criar_tabela_hash(9);
    
    for (int i = 0; i < num_chaves; i++) {
        inserir(th9, chaves[i]);
    }
    
    imprimir_tabela(th9);
    liberar_tabela(th9);
    
    printf("\nTabela Hash com m = 11:\n");
    TabelaHash* th11 = criar_tabela_hash(11);
    
    for (int i = 0; i < num_chaves; i++) {
        inserir(th11, chaves[i]);
    }
    
    imprimir_tabela(th11);
    liberar_tabela(th11);
    
    return 0;
}