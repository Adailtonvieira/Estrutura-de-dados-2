from tabela_hash import TabelaHash
from visualizador import VisualizadorTabelaHash

def testar_tabela_hash():
    chaves = [5, 28, 15, 20, 33, 12, 7, 10]
    visualizador = VisualizadorTabelaHash()
    
    print("\nTabela Hash com m = 9:")
    th9 = TabelaHash(9)
    for chave in chaves:
        th9.inserir(chave)
    visualizador.visualizar(th9)
    
    print("\nTabela Hash com m = 11:")
    th11 = TabelaHash(11)
    for chave in chaves:
        th11.inserir(chave)
    visualizador.visualizar(th11)

if __name__ == "__main__":
    testar_tabela_hash()