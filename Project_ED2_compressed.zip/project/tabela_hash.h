#ifndef TABELA_HASH_H
#define TABELA_HASH_H

#include "no.h"

typedef struct {
    int tamanho;
    No** tabela;
} TabelaHash;

TabelaHash* criar_tabela_hash(int tamanho);
void inserir(TabelaHash* th, int chave);
void imprimir_tabela(TabelaHash* th);
void liberar_tabela(TabelaHash* th);

#endif