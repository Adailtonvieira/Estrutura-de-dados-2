class VisualizadorTabelaHash:
    @staticmethod
    def criar_caixa(largura, texto):
        topo_base = "+" + "-" * largura + "+"
        conteudo = f"|{texto:^{largura}}|"
        return [topo_base, conteudo, topo_base]

    @staticmethod
    def visualizar(tabela_hash):
        largura_caixa = 30
        print("\n" + "=" * (largura_caixa + 2))
        
        for indice, lista in tabela_hash.obter_dados_tabela():
            caixa_indice = VisualizadorTabelaHash.criar_caixa(
                largura_caixa, 
                f"Índice {indice}"
            )
            print("\n".join(caixa_indice))
            if not lista:
                caixa_valor = VisualizadorTabelaHash.criar_caixa(largura_caixa, "VAZIO")
                print("\n".join(caixa_valor))
            else:
                lista_str = " -> ".join(str(chave) for chave in lista)
                caixa_valor = VisualizadorTabelaHash.criar_caixa(largura_caixa, lista_str)
                print("\n".join(caixa_valor))
            
            print("=" * (largura_caixa + 2))