#ifndef NO_H
#define NO_H

typedef struct No {
    int chave;
    struct No* proximo;
} No;

#endif