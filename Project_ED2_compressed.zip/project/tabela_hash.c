#include <stdio.h>
#include <stdlib.h>
#include "tabela_hash.h"

No* criar_no(int chave) {
    No* novo_no = (No*)malloc(sizeof(No));
    novo_no->chave = chave;
    novo_no->proximo = NULL;
    return novo_no;
}

TabelaHash* criar_tabela_hash(int tamanho) {
    TabelaHash* th = (TabelaHash*)malloc(sizeof(TabelaHash));
    th->tamanho = tamanho;
    th->tabela = (No**)malloc(tamanho * sizeof(No*));
    
    for (int i = 0; i < tamanho; i++) {
        th->tabela[i] = NULL;
    }
    return th;
}

int funcao_hash(int chave, int tamanho) {
    return chave % tamanho;
}

void inserir(TabelaHash* th, int chave) {
    int indice = funcao_hash(chave, th->tamanho);
    No* novo_no = criar_no(chave);
    
    if (th->tabela[indice] == NULL) {
        th->tabela[indice] = novo_no;
    }
    else {
        novo_no->proximo = th->tabela[indice];
        th->tabela[indice] = novo_no;
    }
}

void imprimir_tabela(TabelaHash* th) {
    for (int i = 0; i < th->tamanho; i++) {
        printf("\nPosicao %d:", i);
        No* atual = th->tabela[i];
        
        if (atual == NULL) {
            printf(" VAZIO");
        }
        
        while (atual != NULL) {
            printf(" -> %d", atual->chave);
            atual = atual->proximo;
        }
    }
    printf("\n");
}

void liberar_tabela(TabelaHash* th) {
    for (int i = 0; i < th->tamanho; i++) {
        No* atual = th->tabela[i];
        while (atual != NULL) {
            No* temp = atual;
            atual = atual->proximo;
            free(temp);
        }
    }
    free(th->tabela);
    free(th);
}