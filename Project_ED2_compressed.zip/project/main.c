#include <stdio.h>
#include "hash_table.h"

int main() {
    int keys[] = {5, 28, 15, 20, 33, 12, 7, 10};
    int numKeys = 8;
    
    printf("\nTabela Hash com m = 9:\n");
    HashTable* ht9 = createHashTable(9);
    
    for (int i = 0; i < numKeys; i++) {
        insert(ht9, keys[i]);
    }
    
    printHashTable(ht9);
    freeHashTable(ht9);
    
    printf("\nTabela Hash com m = 11:\n");
    HashTable* ht11 = createHashTable(11);
    
    for (int i = 0; i < numKeys; i++) {
        insert(ht11, keys[i]);
    }
    
    printHashTable(ht11);
    freeHashTable(ht11);
    
    return 0;
}